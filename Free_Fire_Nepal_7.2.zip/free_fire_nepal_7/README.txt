FREE FIRE NEPAL 7.2 — INDEPENDENT FAN-MADE NEPAL GAMING HUB

Included:
- Cinematic animated opening screen and responsive mobile-first lobby.
- Nepal profile: nickname, province, role, profile photo upload, Nepal flag frame.
- Official Garena character-name directory based on the official character page checked for this build.
- Original Nepal/world history-inspired fan characters with clearly labelled fictional skills.
- Armory reference catalogue with weapon names, categories and short descriptions based on Garena's official weapons catalogue.
- Existing Nepal community, training, events, map concept, ping observations and local settings features.
- PWA manifest, icon and service worker for installable/offline app-shell use when hosted on HTTPS or localhost.

IMPORTANT LIMITATIONS:
This is an independent fan-made companion app, not the official Free Fire game, not made by Garena, and not connected to Garena servers or accounts. It does not provide live multiplayer, matchmaking, official character models, official weapon models, in-game purchases, rank synchronisation, or real game controls. Character/weapon catalogues are reference directories only. Use Garena's official game for live skill values, balance, availability and original artwork. No Garena password or OTP is requested.

Profile photos and app data are stored locally in this browser/device. Do not store sensitive images or personal information.

HOW TO OPEN:
1. Extract the ZIP.
2. Open free_fire_nepal_7/index.html in a modern browser for local demo use.
3. For installable PWA behaviour and offline caching, host the folder on HTTPS (or run it from localhost), then use the browser's Install app / Add to Home Screen option.

Official references checked 7 Nov 2026:
Characters: https://ff.garena.com/en/chars
Weapons: https://ff.garena.com/en/weapons/

All Garena/Free Fire names and trademarks belong to their respective owners. This project is an unofficial community companion.
